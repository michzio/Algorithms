Przesylam 2 pliki jeden HashTab.cpp ktory jest modyfikacja
tablicy haszujacej dla stringow przetestowany 3 testami z
wczesniejszego zadania domowego oraz drugi plik HashTabInt.cpp, 
ktory zostal zastapiony metodami pobierajacymi int. 
(w tym programie nie modyfikowalem komentarzy wiec czasami moze byc wspominane 
o elementach typu string zamiast int) 

Kompilacja: 
> g++ -o hashtab HashTab.cpp
> ./hashtab

> g++ -o hashtab_int HashTabInt.cpp
> ./hashtab_int 
(moze wymagas flagi C++11 - funkcja castowania string na int) 

Plik names.txt jak poprzednio
Natomiast plik numbers.txt wygenerowany na stronie random.org
i zawiera losowe liczby 

