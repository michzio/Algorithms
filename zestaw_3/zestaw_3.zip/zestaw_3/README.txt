OPIS KOMPILACJI I URUCHOMIANIE PROGRAMOW: 

Zadanie 6

Pliki: zadanie6.cpp input6.dat (zawiera ciag zakonczony -1) 
Kompilacja:
> g++ -o zadanie6 zadanie6.cpp
Uruchomienie:
> ./zadanie6 < input6.dat 


Zadanie 7 

Plik: zadanie7.cpp
Kompilacja: 
> g++ -o zadanie7 zadanie7.cpp
Uruchomienie: 
> ./zadanie7


Zadanie 8 

Przywodca ciagu 
Pliki: przywodca.cpp
Kompilacja: 
> g++ -o przywodca przywodca.cpp
Uruchomienie
> ./przywodca


Szukanie Sumy x=a+b
Pliki: szukanie_sumy.cpp
Kompilacja:
> g++ -o szukanie_sumy szukanie_sumy.cpp
Uruchomienie
> ./szukanie_sumy 
> podanie liczby x

Maksymalny segment
Pliki: max_segment.cpp
Kompilacja: 
> g++ -o max_segment max_segment.cpp
Uruchomienie:
> ./max_segment


Najdluzszy podciag malejacy
Pliki: longest_subsequence.cpp
Kompilacja:
> g++ -o longest_subsequence longest_subsequence.cpp
Uruchomienie: 
> ./longest_subsequence

Zlozonosc obliczeniowa - zadanie 3

Pliki: ./zadanie3/
	generatorTest.cpp 
	input.dat
	output.dat
	zestaw2.cpp (zmodyfikowany) 
Kompilacja:
g++ -o generator generatorTest.cpp
g++ -o zestaw2 zestaw2.cpp

Uruchomienie: 

./generator > input.dat
./zestaw2 < input.dat 
lub 
./zesraw2  < input.dat > output.dat 
	


