Na zajeciach od linijki 668
/**** MIN SPANING TREE *****/